// Elementos do modal de verificação de lista

const botao = document.getElementById("abrir_modal"); // Botão de abrir o modal de verificação de lista
const modal = document.getElementById("modal"); // Modal de verificação de lista
const botaoFechar = document.getElementById("fechar_modal"); // Botão de fechar o modal de verificação de lista
const listaFiltros = document.getElementById("lista_filtros"); // Lista de filtros
const botaoCafe = document.getElementById("abrir_cafe_modal"); // Botão de abrir o modal de verificação de café
const cafeModal = document.getElementById("cafe_modal"); // Modal de verificação de café
const conteudoCafeModal = document.getElementById("conteudo_cafe_modal"); // Conteúdo do modal de verificação de café
const botaoFecharCafe = document.getElementById("fechar_cafe_modal"); // Botão de fechar o modal de verificação de café
