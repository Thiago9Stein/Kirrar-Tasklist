// Modal de verificação de lista

botao.addEventListener("click", function () {
    modal.style.display = "flex";
    listaFiltros.innerHTML = "";
    
    fetch("https://sahabiteto.simob.com.br/v2/api/jira/sql-filters", {
        headers: {
            Authorization: "Bearer 7f4082776a7fa5de42b4cbe0751fb993"
        }
    })

        .then(function (response) {
            return response.json();
        })

        .then(function (dados) {
            dados.result.forEach(function (item) {
                const elemento = document.createElement("li");
                elemento.textContent = item.value;

                const botaoRemover = document.createElement("button")
                botaoRemover.textContent = "Excluir";
                botaoRemover.classList.add("botao_remover");
                elemento.appendChild(botaoRemover);
                
                botaoRemover.addEventListener("click", function() {
                    elemento.remove();
                });

                listaFiltros.appendChild(elemento);

            }); 
        });
    });

// Fechar modal de verificação de lista
botaoFechar.addEventListener("click", function () {
    modal.style.display = "none"
});

// Fechar modal de verificação de lista ao clicar fora do modal
modal.addEventListener("click", function (event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
});

// Modal de verificação de café
botaoCafe.addEventListener("click", function () {
    cafeModal.style.display = "flex";
    conteudoCafeModal.textContent = "";

    let cafeNum = Math.floor(Math.random() * 10) + 1;
    if (cafeNum === 1) {
        conteudoCafeModal.textContent = "Sim, tem café!";
    } else {
        conteudoCafeModal.textContent = "Não, não tem café!";
    }
});

// Fechar modal de verificação de café
botaoFecharCafe.addEventListener("click", function () {
    cafeModal.style.display = "none";
});

// Fechar modal de verificação de café ao clicar fora do modal
cafeModal.addEventListener("click", function (event) {
    if (event.target === cafeModal) {
        cafeModal.style.display = "none";
    }
});
