const botao = document.getElementById("abrir_modal");
const modal = document.getElementById("modal");
const botaoFechar = document.getElementById("fechar_modal");
const listaFiltros = document.getElementById("lista_filtros");

botao.addEventListener("click", function () {
    modal.style.display = "flex";
    listaFiltros.innerHTML = "";
    
    fetch("https://sahabiteto.simob.com.br/v2/api/jira/sql-filters", {
        headers: {
            Authorization: "Bearer 7f4082776a7fa5de42b4cbe0751fb993"
        }
    })

        .then(function (response) {
            return response.json();
        })

        .then(function (dados) {
            dados.result.forEach(function (item) {
                const elemento = document.createElement("li");
                elemento.textContent = item.value;

                const botaoRemover = document.createElement("button")
                botaoRemover.textContent = "Excluir";
                botaoRemover.classList.add("botao_remover");
                elemento.appendChild(botaoRemover);
                
                botaoRemover.addEventListener("click", function() {
                    elemento.remove();
                });

                listaFiltros.appendChild(elemento);

            }); 
        });
    });


botaoFechar.addEventListener("click", function () {
    modal.style.display = "none"
});

modal.addEventListener("click", function (event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
});
